class Message:
    def __init__(self, content: str, id: int):
        self.content = content
        self.id = id
